package com.jo.hydrawater

import android.app.*
import android.content.*
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.math.roundToInt

private val Context.dataStore by preferencesDataStore("hydra_data")
private val GOAL = intPreferencesKey("goal_ml")
private val CONSUMED = intPreferencesKey("consumed_ml")
private val LAST_DAY = stringPreferencesKey("last_day")
private val INTERVAL = intPreferencesKey("interval_hours")
private const val CHANNEL = "hydra_reminders"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        setContent { HydraApp() }
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Water reminders", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }
}

data class Saved(val goal: Int, val consumed: Int, val interval: Int)

@Composable
fun HydraApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<Saved?>(null) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        val p = context.dataStore.data.first()
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            .format(java.util.Date())
        val oldDay = p[LAST_DAY]
        val consumed = if (oldDay == today) p[CONSUMED] ?: 0 else 0
        if (oldDay != today) context.dataStore.edit {
            it[CONSUMED] = 0
            it[LAST_DAY] = today
        }
        saved = p[GOAL]?.let { Saved(it, consumed, p[INTERVAL] ?: 2) }
        loading = false
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF00658A))) {
        Surface(Modifier.fillMaxSize()) {
            if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else if (saved == null) {
                Personalize { goal ->
                    scope.launch {
                        context.dataStore.edit {
                            it[GOAL] = goal
                            it[CONSUMED] = 0
                            it[INTERVAL] = 2
                            it[LAST_DAY] = today()
                        }
                        saved = Saved(goal, 0, 2)
                        scheduleReminder(context, 2)
                    }
                }
            } else {
                Home(
                    saved!!,
                    onAdd = { amount ->
                        scope.launch {
                            context.dataStore.edit {
                                it[CONSUMED] = (saved!!.consumed + amount).coerceAtMost(saved!!.goal)
                                it[LAST_DAY] = today()
                            }
                            saved = saved!!.copy(consumed = (saved!!.consumed + amount).coerceAtMost(saved!!.goal))
                        }
                    },
                    onReset = {
                        scope.launch {
                            context.dataStore.edit { it[CONSUMED] = 0; it[LAST_DAY] = today() }
                            saved = saved!!.copy(consumed = 0)
                        }
                    },
                    onEdit = {
                        scope.launch {
                            context.dataStore.edit { it.remove(GOAL) }
                            saved = null
                        }
                    },
                    onInterval = { hours ->
                        scope.launch {
                            context.dataStore.edit { it[INTERVAL] = hours }
                            saved = saved!!.copy(interval = hours)
                            scheduleReminder(context, hours)
                        }
                    }
                )
            }
        }
    }
}

fun today() = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())

@Composable
fun Personalize(onDone: (Int) -> Unit) {
    var age by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("💧", fontSize = 52.sp)
        Spacer(Modifier.height(12.dp))
        Text("Personalize your hydration", style = MaterialTheme.typography.headlineSmall)
        Text("We'll calculate a practical daily starting estimate.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Field("Age", age, { age = it }, "years")
        Field("Height", height, { height = it }, "cm")
        Field("Weight", weight, { weight = it }, "kg")
        if (error) Text("Enter a valid age and weight.", color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                val a = age.toIntOrNull()
                val w = weight.toDoubleOrNull()
                if (a != null && w != null && a in 1..120 && w in 10.0..300.0) {
                    val rate = when { a < 14 -> 35.0; a >= 65 -> 30.0; else -> 33.0 }
                    onDone(((w * rate) / 50).roundToInt() * 50)
                } else error = true
            },
            Modifier.fillMaxWidth().height(52.dp), RoundedCornerShape(28.dp)
        ) { Text("Calculate my goal") }
        Spacer(Modifier.height(12.dp))
        Text("Estimate only; hydration needs vary with activity, climate and health.", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun Field(label: String, value: String, change: (String) -> Unit, suffix: String) {
    OutlinedTextField(
        value = value, onValueChange = { if (it.length < 8 && it.all { c -> c.isDigit() || c == '.' }) change(it) },
        label = { Text(label) }, suffix = { Text(suffix) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp), shape = RoundedCornerShape(18.dp)
    )
}

@Composable
fun Home(
    data: Saved, onAdd: (Int) -> Unit, onReset: () -> Unit, onEdit: () -> Unit, onInterval: (Int) -> Unit
) {
    val progress = (data.consumed.toFloat() / data.goal).coerceIn(0f, 1f)
    var showSettings by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Hydra", style = MaterialTheme.typography.headlineMedium)
                Text("Today's hydration", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { showSettings = !showSettings }) { Text("Settings") }
        }
        Spacer(Modifier.height(24.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(32.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${data.consumed} ml", style = MaterialTheme.typography.displaySmall)
                Text("of ${data.goal} ml", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(18.dp))
                LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth().height(14.dp))
                Spacer(Modifier.height(10.dp))
                Text("${(progress * 100).roundToInt()}% complete")
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("Add water", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button({ onAdd(250) }, Modifier.weight(1f)) { Text("+250 ml") }
            Button({ onAdd(500) }, Modifier.weight(1f)) { Text("+500 ml") }
        }
        if (showSettings) {
            Spacer(Modifier.height(22.dp))
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Reminder interval", style = MaterialTheme.typography.titleMedium)
                    Text("Every ${data.interval} hours", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1,2,3,4).forEach { h ->
                            FilterChip(selected = data.interval == h, onClick = { onInterval(h) }, label = { Text("${h}h") })
                        }
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = onReset) { Text("Reset today") }
            TextButton(onClick = onEdit) { Text("Edit profile") }
        }
    }
}

fun scheduleReminder(context: Context, hours: Int) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(
        context, 1001, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val trigger = System.currentTimeMillis() + hours * 60L * 60L * 1000L
    alarm.cancel(pending)
    alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, trigger, hours * 60L * 60L * 1000L, pending)
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Time for some water 💧")
            .setContentText("Take a short water break and keep up your hydration.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        androidx.core.app.NotificationManagerCompat.from(context).notify(1001, notification)
    }
}
